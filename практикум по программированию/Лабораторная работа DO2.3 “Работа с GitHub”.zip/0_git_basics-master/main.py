print("Hello, world")
print("")
